import sys
from datetime import date
import uuid
import types

import pytest

from ledger.api import cli as cli_mod
from ledger.models import RecordType


def _run_cli(monkeypatch, *argv):
    # 以函数形式运行 CLI，避免真正退出进程
    args = ["prog"] + list(argv)
    monkeypatch.setattr(sys, "argv", args)
    cli_mod.main()


def test_cli_init_add_list_stats_budget_reminder(tmp_path, capsys, monkeypatch):
    db_url = f"sqlite:///{tmp_path}/cli_{uuid.uuid4().hex}.db"

    # init db
    _run_cli(monkeypatch, "init-db", "--db", db_url)
    out = capsys.readouterr().out
    assert "Initialized database" in out

    # add records
    _run_cli(
        monkeypatch,
        "add",
        "--db",
        db_url,
        "--user",
        "alice",
        "--type",
        "INCOME",
        "--category",
        "salary",
        "--amount",
        "1000",
        "--date",
        "2025-01-01",
    )
    _run_cli(
        monkeypatch,
        "add",
        "--db",
        db_url,
        "--user",
        "alice",
        "--type",
        "EXPENSE",
        "--category",
        "food",
        "--amount",
        "120.5",
        "--date",
        "2025-01-02",
        "--note",
        "noodles",
    )

    # list
    _run_cli(
        monkeypatch, "list", "--db", db_url, "--user", "alice", "--month", "2025-01"
    )
    out = capsys.readouterr().out
    assert "food" in out and "salary" in out

    # stats
    _run_cli(
        monkeypatch, "stats", "--db", db_url, "--user", "alice", "--month", "2025-01"
    )
    out = capsys.readouterr().out
    assert "income" in out and "expense" in out and "balance" in out

    # budget set/list/progress
    _run_cli(
        monkeypatch,
        "budget",
        "--db",
        db_url,
        "set",
        "--user",
        "alice",
        "--category",
        "food",
        "--limit",
        "1000",
    )
    _run_cli(monkeypatch, "budget", "--db", db_url, "list", "--user", "alice")
    out = capsys.readouterr().out
    assert "food" in out and "1000" in out

    _run_cli(
        monkeypatch,
        "budget",
        "--db",
        db_url,
        "progress",
        "--user",
        "alice",
        "--month",
        "2025-01",
    )
    out = capsys.readouterr().out
    assert "Budget progress" in out and "food" in out

    # reminder set/list/emit
    _run_cli(
        monkeypatch,
        "reminder",
        "--db",
        db_url,
        "set",
        "--user",
        "alice",
        "--time",
        "21:00",
        "--message",
        "记账",
    )
    _run_cli(monkeypatch, "reminder", "--db", db_url, "list", "--user", "alice")
    out = capsys.readouterr().out
    assert "21:00" in out

    _run_cli(monkeypatch, "reminder", "--db", db_url, "emit", "--user", "alice")
    out = capsys.readouterr().out
    assert "reminder" in out or "记账" in out


@pytest.mark.skipif(
    "csv_io" not in sys.modules and False, reason="csv import/export optional"
)
def test_cli_import_export_smoke(tmp_path, capsys, monkeypatch):
    """
    可选：如果你实现了 csv_io，可打开上面的 skip 条件并补充：
      - 在 tmp_path 创建一个 CSV
      - 运行 import-csv / export-csv
      - 断言导入/导出数量与内容
    这里默认跳过。
    """
    pass
