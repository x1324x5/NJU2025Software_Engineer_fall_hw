from ledger.models import User
from ledger.repo.sqlite_user_repo import SqliteUserRepository
from ledger.utils.db import init_db, get_session_factory
import uuid


def test_user_add_and_get_by_name(tmp_path):
    db_url = f"sqlite:///{tmp_path}/user_{uuid.uuid4().hex}.db"
    init_db(db_url=db_url)
    SessionFactory = get_session_factory(db_url=db_url)
    session = SessionFactory()

    repo = SqliteUserRepository(session)
    u = repo.add(User(None, "alice", "a@example.com"))
    assert u.user_id is not None

    got = repo.get_by_name("alice")
    assert got is not None and got.user_id == u.user_id and got.email == "a@example.com"
