"""Repositories for persistence and I/O."""
